from flask import Flask
from recycle.routes import recycle_bp
import sys
import os

# 获取 shared.py 所在目录的绝对路径
shared_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(shared_dir)

from shared import init_shared, db

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///recycle.db'

# 初始化共享模块
init_shared(app)

# 注册蓝图
app.register_blueprint(recycle_bp)

# 运行应用
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # 创建回收板块特有数据表
    app.run(port=5001, debug=True)