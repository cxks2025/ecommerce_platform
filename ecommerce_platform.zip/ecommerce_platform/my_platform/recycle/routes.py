from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from platform.shared.shared import db, User, Order
from recycle.models import RecycleProduct

recycle_bp = Blueprint('recycle', __name__)

# 首页
@recycle_bp.route('/')
def home():
    return render_template('recycle/index.html')

# 登录
@recycle_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            session['user_id'] = user.id
            flash('登录成功！', 'success')
            return redirect(url_for('recycle.home'))
        else:
            flash('用户名或密码错误', 'error')
    return render_template('recycle/login.html')

# 注册
@recycle_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        email = request.form.get('email')
        new_user = User(username=username, password=password, email=email)
        db.session.add(new_user)
        db.session.commit()
        flash('注册成功！请登录。', 'success')
        return redirect(url_for('recycle.login'))
    return render_template('recycle/register.html')

# 商品展示
@recycle_bp.route('/products')
def products():
    products = RecycleProduct.query.all()
    return render_template('recycle/products.html', products=products)

# 支付
@recycle_bp.route('/checkout', methods=['POST'])
def checkout():
    if 'user_id' not in session:
        flash('请先登录', 'error')
        return redirect(url_for('recycle.login'))
    
    product_id = request.form.get('product_id')
    quantity = int(request.form.get('quantity', 1))
    
    product = RecycleProduct.query.get(product_id)
    if not product:
        flash('商品不存在', 'error')
        return redirect(url_for('recycle.products'))
    
    # 创建订单
    new_order = Order(
        user_id=session['user_id'],
        product_id=product_id,
        quantity=quantity,
        total_amount=product.price * quantity
    )
    db.session.add(new_order)
    db.session.commit()
    
    flash('支付成功！', 'success')
    return redirect(url_for('recycle.products'))