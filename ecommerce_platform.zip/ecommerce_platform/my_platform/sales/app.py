from flask import Flask
import logging
from logging.handlers import RotatingFileHandler
import sys
import os

# 获取 shared.py 所在目录的绝对路径
shared_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(shared_dir)

from shared import init_shared, db  # type: ignore # 导入共享模块
from sales.routes import sales_bp   # type: ignore # 导入销售板块蓝图

# 配置日志
log_file = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'shared', 'certs', 'logs', 'app.log'))
os.makedirs(os.path.dirname(log_file), exist_ok=True)  # 确保日志目录存在

handler = RotatingFileHandler(log_file, maxBytes=1024 * 1024, backupCount=10)
handler.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)

# 添加到根日志记录器
logging.getLogger().addHandler(handler)

# 创建 Flask 应用
app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sales.db'

# 初始化共享模块
init_shared(app)

# 注册蓝图
app.register_blueprint(sales_bp)

# 运行应用
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # 创建销售板块特有数据表
    app.run(port=5000, debug=True)