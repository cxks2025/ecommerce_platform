from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from sales.models import SaleProduct, Cart
import sys
import os
from ..shared.shared import db, User, Order  # 使用相对导入
# 获取 platform 目录的绝对路径
platform_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.append(platform_dir)

from platform.sales.models import SaleProduct, Cart

# 创建蓝图
sales_bp = Blueprint('sales', __name__)

# 定义路由
@sales_bp.route('/')
def index():
    return "Sales Home Page"

sales_bp = Blueprint('sales', __name__)

# 首页
@sales_bp.route('/')
def home():
    return render_template('sales/index.html')

# 登录
@sales_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            session['user_id'] = user.id
            flash('登录成功！', 'success')
            return redirect(url_for('sales.home'))
        else:
            flash('用户名或密码错误', 'error')
    return render_template('sales/login.html')

# 注册
@sales_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        email = request.form.get('email')
        new_user = User(username=username, password=password, email=email)
        db.session.add(new_user)
        db.session.commit()
        flash('注册成功！请登录。', 'success')
        return redirect(url_for('sales.login'))
    return render_template('sales/register.html')

# 商品展示
@sales_bp.route('/products')
def products():
    products = SaleProduct.query.all()
    return render_template('sales/products.html', products=products)

# 购物车
@sales_bp.route('/cart', methods=['GET', 'POST'])
def cart():
    if 'user_id' not in session:
        flash('请先登录', 'error')
        return redirect(url_for('sales.login'))
    
    if request.method == 'POST':
        product_id = request.form.get('product_id')
        quantity = int(request.form.get('quantity', 1))
        
        product = SaleProduct.query.get(product_id)
        if not product:
            flash('商品不存在', 'error')
            return redirect(url_for('sales.products'))
        
        if product.stock < quantity:
            flash('库存不足', 'error')
            return redirect(url_for('sales.products'))
        
        # 添加到购物车
        cart_item = Cart(user_id=session['user_id'], product_id=product_id, quantity=quantity)
        db.session.add(cart_item)
        db.session.commit()
        flash('已添加到购物车', 'success')
    
    cart_items = Cart.query.filter_by(user_id=session['user_id']).all()
    return render_template('sales/cart.html', cart_items=cart_items)

# 支付
@sales_bp.route('/checkout', methods=['POST'])
def checkout():
    if 'user_id' not in session:
        flash('请先登录', 'error')
        return redirect(url_for('sales.login'))
    
    cart_items = Cart.query.filter_by(user_id=session['user_id']).all()
    total_amount = sum(item.product.price * item.quantity for item in cart_items)
    
    # 创建订单
    new_order = Order(
        user_id=session['user_id'],
        total_amount=total_amount,
        status='pending'
    )
    db.session.add(new_order)
    db.session.commit()
    
    # 清空购物车
    Cart.query.filter_by(user_id=session['user_id']).delete()
    db.session.commit()
    
    flash('支付成功！', 'success')
    return redirect(url_for('sales.products'))