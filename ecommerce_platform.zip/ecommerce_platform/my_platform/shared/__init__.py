from .shared import db, init_shared

def init_shared(app):
    db.init_app(app)
    with app.app_context():
        db.create_all()  # 创建共享数据表