from flask_sqlalchemy import SQLAlchemy

# 初始化 SQLAlchemy
db = SQLAlchemy()

# 定义共享的模型
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    total_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(50), nullable=False)

# 初始化共享模块
def init_shared(app):
    db.init_app(app)
    with app.app_context():
        db.create_all()  # 创建共享数据表