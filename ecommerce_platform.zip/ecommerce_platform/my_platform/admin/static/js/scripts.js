// 自定义 JavaScript
document.addEventListener('DOMContentLoaded', function () {
    // 示例：动态加载商品详情
    const productLinks = document.querySelectorAll('.product-link');
    productLinks.forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            const productId = this.getAttribute('data-product-id');
            window.location.href = `/product/${productId}`;
        });
    });

    // 示例：购物车功能
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function () {
            const productId = this.getAttribute('data-product-id');
            alert(`Product ${productId} added to cart!`);
        });
    });
});