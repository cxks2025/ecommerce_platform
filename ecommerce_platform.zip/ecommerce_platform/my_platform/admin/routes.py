from flask import Blueprint, render_template, request, redirect, url_for, flash
from ecommerce_platform.shared.shared import db, User, Order
from admin.models import SupportTicket

admin_bp = Blueprint('admin', __name__)

# 经营数据视图
@admin_bp.route('/dashboard')
def dashboard():
    total_users = User.query.count()
    total_orders = Order.query.count()
    return render_template('admin/dashboard.html', 
                          total_users=total_users, 
                          total_orders=total_orders)

# 客服模块
@admin_bp.route('/support')
def support():
    tickets = SupportTicket.query.all()
    return render_template('admin/support.html', tickets=tickets)

# 装卸模块
@admin_bp.route('/loading')
def loading():
    return render_template('admin/loading.html')

# 支付通道配置
@admin_bp.route('/payment_config', methods=['GET', 'POST'])
def payment_config():
    if request.method == 'POST':
        # 处理支付通道配置
        flash('支付通道配置已更新', 'success')
    return render_template('admin/payment_config.html')